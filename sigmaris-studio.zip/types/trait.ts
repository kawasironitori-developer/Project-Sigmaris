// types/trait.ts
export interface Trait {
  calm: number;
  empathy: number;
  curiosity: number;
}
