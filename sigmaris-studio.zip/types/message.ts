export interface ChatMessage {
  user: string;
  ai: string;
}
